import axios from 'axios';
import React from 'react'
import { useNavigate } from "react-router-dom";
const Thanks = () => {
    const navigate = useNavigate();
    const handleClick = (e) => {
        e.preventDefault();
        navigate('/')
    }
  return (
    <div>
        Your Payment is Successful. 
        <br /><br />
        <button onClick={handleClick}>Click here</button>   
        to redirect back
    </div>
  )
}

export default Thanks