import React from 'react'
import { useForm } from "react-hook-form";
import axios from "axios";
import { useNavigate } from "react-router-dom";
const Payment = () => {

    const { register, handleSubmit,reset } = useForm();
    const navigate = useNavigate();

    const onSubmit = async(data) => {

        
        try{     
            axios.post(
            "http://localhost:5000/payment",
           
        ).then( res => navigate("/thanks"))
        .catch(err => {
            
        })
        reset();
        }
        catch(err){
            
        }

    }
  return (
    <div>
        <h3>Select the payment method</h3>
        <p>Monthy Charges for the Yoga Classes will be 500/- INR</p>
        <p>Batch can only be changed on monthly basis only</p>
        <form onSubmit={handleSubmit(onSubmit)} className="">
        <input type="radio" {...register("paymentMethod")} name="payment" value="UPI"  /><p>UPI</p>
        <input type="radio"  {...register("paymentMethod")} name="payment" value="Debit Card"  /><p>Debit Card</p>
        <input type="radio"  {...register("paymentMethod")} name="payment" value="Credit Card"  /><p>Credit Card</p>
        <input type="radio"  {...register("paymentMethod")} name="payment" value="Other Wallets"  /><p>Other Wallets</p>
        <input type="submit" />
        </form>
    </div>
  )
}

export default Payment