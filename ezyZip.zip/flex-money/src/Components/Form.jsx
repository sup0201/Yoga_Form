import { useState } from "react"
import { useForm } from "react-hook-form";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import './Form.css'

const Form = () => {

    const { register, handleSubmit,reset } = useForm();
    const [Error, setError] = useState(false);
    const navigate = useNavigate();
    const onSubmit = async(data) => {

        const updatedData = {
            ...data,
            age: +data.age
        }

        try{     
            axios.post(
            "http://localhost:5000/addUser",
                updatedData
            
            
        ).then( res => navigate("/payment"))
        .catch(err => {
            setError(!Error)
        })
        reset();
        }
        catch(err){
            
        }
       
    };


  return (
    <div className="formContainer">
        <form onSubmit={handleSubmit(onSubmit)} className="form">
            <label htmlFor="FirstName">First Name</label>
                <input {...register("firstName")} id="FirstName" placeholder="First Name" className="outline" />
            <label htmlFor="LastName">Last Name</label>
                <input {...register("lastName")} id="LastName" placeholder="Last Name" className="outline" />
            <label htmlFor="email">Email</label>
            <input {...register("email")} type="email" id="email" placeholder="email" className="outline" />
            <label htmlFor="Age">Age</label>
            <div className="flex-1">
                <input type="number" {...register("age")} id="Age" placeholder="Age" min="18" max="65" className="outline"  /><p>years</p>
            </div>
            <label htmlFor="Batch">Batch Timings</label>
            <select {...register("batch_timings")} id="Batch" className="outline">
                <option value="6-7 AM">6-7 AM</option>
                <option value="7-8 AM">7-8 AM</option>
                <option value="8-9 AM">8-9 AM</option>
                <option value="5-6 PM">5-6 PM</option>
            </select>
            <input type="submit" />
        </form>
      
  </div>
  )
}

export default Form