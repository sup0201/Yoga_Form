import logo from './logo.svg';
import './App.css';
import Form from './Components/Form';
import { Routes, Route } from "react-router-dom";
import Payment from './Components/Payment';
import Thanks from './Components/thanks';
function App() {
  return (
    <div className="App">
        
        <Routes>
          <Route index element={<Form />} />
          <Route path="payment" element={<Payment />} />
          <Route path="thanks" element={<Thanks />} />
          {/* <Route path="*" element={<NoPage />} /> */}
      </Routes>
    </div>
  );
}

export default App;
