const joi = require("joi");
const errorFunction = require("../././utils/errorFunction");

const validation = joi.object({
     firstName: joi.string().trim(true).required(),
     lastName: joi.string().trim(true).required(),
     email: joi.string().email().trim(true).required(),
     age: joi.number().integer().min(18).max(65),
     batch_timings: joi.string().trim(true).required(),
});

const userValidation = async (req, res, next) => {
	const payload = {
		firstName: req.body.firstName,
		lastName: req.body.lastName,
		age: req.body.age,
        email: req.body.email,
		batch_timings: req.body.batch_timings,
	};

	const { error } = validation.validate(payload);
	if (error) {
		res.status(406);
		return res.json(
			errorFunction(true, `Error in User Data : ${error.message}`)
		);
	} else {
		next();
	}
};
module.exports = userValidation;