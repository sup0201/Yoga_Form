// const User = require("../models").User;
const errorFunction = require("../utils/errorFunction");

const completePayment = async (req, res, next) => {
	try {
		return res.status(200).json({message: "success"})
	} catch (error) {
		res.status(400);
		console.log(error);
		return res.json(errorFunction(true, "Error with payment method"));
	}
};

module.exports = { completePayment };






















