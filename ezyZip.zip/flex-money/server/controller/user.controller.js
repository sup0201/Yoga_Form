const User = require("../models").User;
const errorFunction = require("../utils/errorFunction");

const addUser = async (req, res, next) => {
	try {
		const existingUser = await User.findOne(
			{ where: { email: req.body.email } } ,
		)
		if (existingUser) {
			res.status(403);
			return res.json(errorFunction(true, "User Already Exists"));
			} else {
				const newUser = await User.create({
					firstName: req.body.firstName,
					lastName: req.body.lastName,
                    email: req.body.email,
					age: req.body.age,
					batch_timings: req.body.batch_timings,
			});
			if (newUser) {
				res.status(201);
				return res.json(
					errorFunction(false, "User Created", newUser)
				);
			} else {
				res.status(403);
				return res.json(errorFunction(true, "Error Creating User"));
			}
		}
	} catch (error) {
		res.status(400);
		console.log(error);
		return res.json(errorFunction(true, "Error Adding user"));
	}
};

module.exports = { addUser };