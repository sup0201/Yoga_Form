const express = require("express");
const userValidation = require("../validation/user");

const { addUser } = require("../controller/user.controller");


const router = express.Router();

router.post("/addUser", userValidation, addUser);


module.exports = router;