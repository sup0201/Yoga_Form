const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const mysql = require("mysql2");
const { sequelize } = require('sequelize');
const userRoutes = require("./routes/user");
const paymentRoutes = require("./routes/payment");
const db = require("./models");
const app = express();

const dbconnection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: "Ishan2001@",
  database: 'test'
});

app.use(express.json());

app.use(express.urlencoded({extended: false}));

app.use(helmet());

app.use(cors());

app.use('/', userRoutes);
app.use('/', paymentRoutes);

app.get( "/" , (req , res) => {

    console.log("Welcome to the flex money")

    return res.json({message : "Oh yeah!!!"})
  } )

 db.sequelize.sync().then((req) => {
  app.listen ( 5000, (req,res) => {
  
  })
 })
